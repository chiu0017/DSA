#include<iostream>

using namespace std;

struct user{
	int userid;
	string username;
	int quiz[3];
};

user input();
user display(user t1);
int again();
int fail(int temp);

int ctr0 = 1;

int main(){
	
	user t1;
	LOOP4:
	int ctr = 0;
	
	t1 = input();
	t1 = display(t1);
	ctr = again();
	
	if(ctr == 1){
		goto LOOP4;
	}else{
		return 0;
	}
	
}

user input(){
	
	user temp1;
	int ctr = 0;
	
	LOOP1:
	
	cout	<< "***Enter User Info:***\n";
	cout	<< "Enter Id: ";
	cin		>> temp1.userid;
	
	if(cin.fail()){
		fail(0);
		goto LOOP1;
	}
	
	cout	<< "Enter Name: ";
	cin		>> temp1.username;
	
	
	if(cin.fail()){
		fail(1);
		goto LOOP1;
	}
	
	LOOP2:
	
	while (ctr < 3){
		
		cout	<< "Enter Quiz " << ctr + 1 << ": ";
		cin		>> temp1.quiz[ctr];
		
		if(cin.fail()){
			ctr = 0;
			fail(0);
			goto LOOP2;
		}
		
		if(temp1.quiz[ctr] < 0){
			cout	<< "\nPlease input positive integers!\n\n";
			ctr = 0;
			goto LOOP2;
		}
		
		ctr++;
	}
	
	
	return temp1;
	
}


user display(user t1){
	
	cout	<< "\n\n\n"
			<< "***Student Record***\n"
			<< "ID: " << t1.userid << "\n"
			<< "Name: " << t1.username << "\n"
			<< "Quiz 1: " << t1.quiz[0] << "\n"
			<< "Quiz 2: " << t1.quiz[1] << "\n"
			<< "Quiz 3: " << t1.quiz[2] << "\n";
	
	return t1;
	
}

int again(){
	
	string choice = "";
	LOOP3:
	
	cout	<< "\n\n"
			<< "***Input Another?***\n"
			<< "y/n: ";
	cin		>> choice;
	
	if(choice == "y" || choice == "Y"){
		cout	<< "\n";
		return 1;
	}else if (choice == "n" || choice == "N"){
		cout	<< "\n";
		return 0;
	}else{
			cout	<< "\n\n"
					<< "Please Input within specified Choices: \n";
			goto LOOP3;
	}
}


int fail(int temp){
        cin.clear(); 
		cin.ignore(100,'\n');
		if(temp == 1){
			cout	<< "\nPlease input proper letters!\n";
		}else{
			cout	<< "\nPlease input real numbers!\n";
		}
		
}
