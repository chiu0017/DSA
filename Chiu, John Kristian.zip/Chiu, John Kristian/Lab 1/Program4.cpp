
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()

{
int a,b;
char again;
Start:{
 
char str[100];
system("cls");
printf("Enter a word:");
gets(str);
a=strlen(str);
for(b=0;b<a/2;b++){
	
	if(str[b]!=str[a-1-b]){
		printf("It's not a palindrome");
		break;
	}
}
if(b==a/2)
	{
	printf("It's a Palindrome");
	}

}
Initiate:{printf("\nDo you want to try again?[Y/N]:");
scanf("%s", &again);
fflush(stdin);

if(again=='Y'||again=='y'){
	goto Start;

}

if(again=='N'||again=='n'){
	printf("Thank You for using this application!");
	return 0;
}
else{
	printf("Invalid Input\n");
	goto Initiate;
}
}
}
