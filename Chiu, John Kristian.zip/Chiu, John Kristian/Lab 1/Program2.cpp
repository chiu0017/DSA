#include<iostream>
#include<stdlib.h>
#include "checker.h"
using namespace std;

int main()
{
	Start:{
	char again[5];
	int i=1, j, checker;
	int a[10], number;
	system("cls");
		printf("\n Please enter the Number you want to convert:");
		scanf("%d",&number);
		number=number;
	
	{
		for(i=0; number>0; i++)
		{
			a[i]=number%2;
			number=number/2;
		}
		printf("\n Binary Number of a given number= ");
		for(j=i-1;j>=0;j--)
		{
		printf("%d",a[j]);
		}
	}
	Initiate:{printf("\nDo you want to try again?[Y/N]:");
	scanf("%s", &again);
	fflush(stdin);

	if(again[0]=='Y'||again[0]=='y'){
		goto Start;

	}

	if(again[0]=='N'||again[0]=='n'){
		printf("Thank You!");
		return 0;
	}
	else{
		printf("Invalid Input\n");
		goto Initiate;
	 }
}
}
}
