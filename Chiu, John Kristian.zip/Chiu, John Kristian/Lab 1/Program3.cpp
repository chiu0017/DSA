#include <iostream>
using namespace std;
int main(){
	int numbers[10];
	
	cout<<"Enter 10 numbers"<<endl;
	for (int i = 1; i<=10;i++){
	while(!(cin>> numbers[i])){
		cout<<"Invalid input try again."<<endl;
		cin.clear();
		cin.sync();
		}	
	}
	
	
	int HighNum,HighNum2;
	int LowNum2 = numbers[0];
	int LowNum = numbers[0];

	for (int count1 = 1; count1<=10; count1++){
		if(numbers[count1]>HighNum){
		HighNum= numbers[count1];
		}
	}
	for (int count2 = 1;count2<=10; count2++){
	if(numbers[count2]>HighNum2 && numbers[count2]<HighNum){
	HighNum2= numbers[count2];	
		}
	}
	
	for(int count3= 1;count3<=10;count3++){
	if(numbers[count3]<LowNum){
	LowNum = numbers[count3];
		}
	}
	for(int count4= 1;count4<=10;count4++){
		if(numbers[count4]<LowNum2 && numbers[count4]>LowNum){
			LowNum2 = numbers[count4];
		}
	}
	
	cout<<"First to Highest: "<<HighNum<<endl;
	cout<<"Second to Highest: "<<HighNum2<<endl;
	cout<<"First to Lowest: "<<LowNum<<endl;
	cout<<"Second to Lowest: "<<LowNum2<<endl;
}

