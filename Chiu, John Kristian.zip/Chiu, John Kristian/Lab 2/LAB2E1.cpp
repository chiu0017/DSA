#include <iostream>

using namespace std;

int main()
{
	cout<<"________________________________________________\n\n";
	cout<<"    Computing Areas of Polygon and Circle!!    \n";
	cout<<"________________________________________________\n\n";
	int choice;
	bool gameOn = true;
	while (gameOn != false)
	{
		cout<<"Choose what Area to compute: \n";
		
		cout<<"  1 - Area of Square \n";
		cout<<"  2 - Area of Rectangle\n";
		cout<<"  3 - Area of Triangle\n";
		cout<<"  4 - Area of Circle \n";
		cout<<"  5 - Exit\n\n";
		cout<<"Select between 1-5 and press ENTER: ";

		cin>>choice;

	switch(choice)
		{
			case 1:	
				cout<<"Enter side of Square \n";
					int side, area1;
					cin>>side;
					area1 = side * side;	
			cout<<"The area is "<<area1<< " sq. units" <<endl;
			break;
			
			case 2:	
			cout<<"Enter Length: ";	
				int width, length, area2;
				cin>>length;
				cout<<"Enter Width: ";
				cin>>width;
				area2 = length * width;	
			cout<<"The Area is "<<area2<< " sq. units" <<endl;
			break;
			
			case 3:		
				cout<<"Enter Base: ";
					int base, height, area3;
					cin>>base;
					cout<<"Enter Height: ";
					cin>>height;
					area3 = (base * height) / 2;
			cout<<"The Area is "<<area3<< " sq. units" <<endl;
			break;
			
			case 4:	
				cout<<"Enter Radius \n";
					double radius, area4;
					cin>>radius;
					area4 = (radius*radius)*3.14159265359;
				cout<<"The Area is "<<area4<< " sq. units" <<endl;
			break;
			
			case 5:	
				cout<<"Thank You!\n";
					gameOn = false;
					break;
					default:	
			cout<<"Not a Valid Choice. \n";
			cout<<"Choose again.\n";
			cin>>choice;
			break;
		}
	}
	return 0;
}
